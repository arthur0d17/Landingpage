# Arthur Rodrigues — landing page para cliente final

## Abrir e editar

Abra `dist/index.html` no navegador. A página funciona diretamente, sem instalação. A prévia local desta sessão está em http://127.0.0.1:4173/.

- `dist/index.html`: página completa, textos, links, ilustrações e acordeão nativo.
- `dist/styles.css`: identidade visual, componentes e regras responsivas.

Os blocos HTML são identificados por seção e os estilos por classes descritivas. Edite esses dois arquivos diretamente; não há compilação obrigatória. Manrope é carregada pelo Google Fonts; sem conexão, Arial é usada como alternativa. As ilustrações são HTML/CSS e SVG, sem imagens pesadas ou dependências de JavaScript.

## Materiais reais pendentes

1. Portfólio: capturas de páginas reais, nome autorizado do negócio, segmento, breve descrição do trabalho e endereço público, se disponível. Substitua as três figuras demonstrativas na seção `projetos`. Depois, use a introdução original do briefing: “Conheça páginas que desenvolvi para apresentar serviços e facilitar o contato com cada negócio.”
2. Depoimentos: texto verdadeiro aprovado para uso, nome e identificação profissional autorizados. Nenhum depoimento fictício foi inserido. Os benefícios e a lista de entrega mencionam o recurso conforme a copy fornecida.

## Contatos e comportamento

Todos os CTAs comerciais levam a `https://wa.me/5579998386098` com a mensagem do briefing corretamente codificada. A mensagem não é enviada automaticamente. Instagram: `https://www.instagram.com/oarthurodriguez/`.

O formulário do hero é uma ilustração: não coleta dados. O acordeão usa `details` e `summary`, com abertura nativa por teclado. O conteúdo e todos os links funcionam sem JavaScript. Não foram incluídos rastreamento, analytics, credenciais, preços ou resultados inventados.

## Publicação

A página não foi publicada. Quando houver autorização, os arquivos de `dist` são os arquivos públicos a hospedar. Este pacote não modifica o site de referência.

## Conferências realizadas

- Larguras 360, 390, 768, 1280 e 1440 px: nenhum elemento ultrapassando horizontalmente a página.
- Um único H1, títulos de seção e destinos de âncoras existentes.
- Seis perguntas completas; abertura e fechamento por teclado conferidos.
- Fonte Manrope carregada na prévia; foco visível e redução de movimento definidos.
- Links de contato conferidos na página. Nenhuma mensagem foi enviada.

As verificações são locais; não representam uma publicação ou validação de atendimento real pelo WhatsApp.
